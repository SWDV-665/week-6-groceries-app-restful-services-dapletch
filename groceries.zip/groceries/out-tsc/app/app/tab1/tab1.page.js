import { __decorate } from "tslib";
import { Component } from '@angular/core';
let Tab1Page = class Tab1Page {
    constructor() {
        this.name = 'Seth Pletcher';
        this.id = '0926867';
    }
};
Tab1Page = __decorate([
    Component({
        selector: 'app-tab1',
        templateUrl: 'tab1.page.html',
        styleUrls: ['tab1.page.scss']
    })
], Tab1Page);
export { Tab1Page };
//# sourceMappingURL=tab1.page.js.map