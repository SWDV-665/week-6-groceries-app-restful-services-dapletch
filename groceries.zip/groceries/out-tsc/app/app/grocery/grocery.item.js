export class GroceryItem {
    constructor() {
        let quantity = this.quantity != null || this.quantity !== undefined ? this.quantity : 0.00;
        let price = this.price != null || this.price !== undefined ? this.price : 0.00;
        this.totalCost = quantity * price;
    }
    /**
     * Formats the totalCost variable for the purposes of display
     * @param locale - 'en-US'
     * @param style - 'currency'
     * @param currency - 'USD'
     */
    formatTotalCost(locale, style, currency) {
        let formatter = new Intl.NumberFormat(locale, {
            style: style,
            currency: currency,
        });
        return formatter.format(this.totalCost);
    }
}
//# sourceMappingURL=grocery.item.js.map