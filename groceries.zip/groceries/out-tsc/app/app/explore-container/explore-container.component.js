import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
let ExploreContainerComponent = class ExploreContainerComponent {
    constructor() { }
    ngOnInit() { }
};
__decorate([
    Input()
], ExploreContainerComponent.prototype, "name", void 0);
__decorate([
    Input()
], ExploreContainerComponent.prototype, "id", void 0);
ExploreContainerComponent = __decorate([
    Component({
        selector: 'app-explore-container',
        templateUrl: './explore-container.component.html',
        styleUrls: ['./explore-container.component.scss'],
    })
], ExploreContainerComponent);
export { ExploreContainerComponent };
//# sourceMappingURL=explore-container.component.js.map