import { __awaiter, __decorate } from "tslib";
import { Component } from '@angular/core';
let Tab2Page = class Tab2Page {
    constructor(toastCtrl, alertController, dataService, inputDialogService, socialSharing) {
        this.toastCtrl = toastCtrl;
        this.alertController = alertController;
        this.dataService = dataService;
        this.inputDialogService = inputDialogService;
        this.socialSharing = socialSharing;
    }
    loadItems() {
        return this.dataService.getItems();
    }
    removeItem(item, index) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("Removing Item - ", item, index);
            const toast = yield this.toastCtrl.create({
                message: 'Removing Item - ' + index + " ...",
                duration: 3000
            });
            toast.present();
            this.dataService.removeItem(index);
        });
    }
    shareItem(item, index) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("Sharing Item - ", item, index);
            const toast = yield this.toastCtrl.create({
                message: 'Sharing Item - ' + index + " ...",
                duration: 3000
            });
            toast.present();
            let message = "Grocery Item - Name: " + item.name + " - Quantity: " + item.quantity;
            let subject = "Shared via Groceries app";
            this.socialSharing.share(message, subject).then(() => {
                // Sharing via email is possible
                console.log("Shared successfully!");
            }).catch((error) => {
                console.error("Error while sharing ", error);
            });
        });
    }
    editItem(item, index) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("Edit Item - ", item, index);
            const toast = yield this.toastCtrl.create({
                message: 'Editing Item - ' + index + " ...",
                duration: 3000
            });
            toast.present();
            this.inputDialogService.showPrompt(item, index);
        });
    }
    addItem() {
        console.log("Adding Item");
        this.inputDialogService.showPrompt();
    }
};
Tab2Page = __decorate([
    Component({
        selector: 'app-tab2',
        templateUrl: 'tab2.page.html',
        styleUrls: ['tab2.page.scss']
    })
], Tab2Page);
export { Tab2Page };
//# sourceMappingURL=tab2.page.js.map